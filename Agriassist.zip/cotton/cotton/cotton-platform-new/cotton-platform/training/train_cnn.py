"""a

Train a cotton leaf disease classifier (transfer learning, EfficientNet-B0).

WHERE TO RUN: Kaggle Notebooks or Google Colab (both give a free GPU).
This will NOT run usefully on a laptop CPU for full training.

DATA: Search Kaggle for "cotton leaf disease" or "PlantVillage cotton" dataset.
Expected folder layout after download:

    data/
      train/
        healthy/
        bacterial_blight/
        bollworm/
        whitefly/
        leaf_spot/
      val/
        healthy/
        bacterial_blight/
        ...

Adjust the class folder names below to match whatever dataset you pick.

USAGE (on Kaggle/Colab):
    !pip install torch torchvision -q
    python train_cnn.py
"""

import torch
import torch.nn as nn
from torch.utils.data import DataLoader
from torchvision import datasets, transforms, models

DATA_DIR = "data"          # change to your dataset path
NUM_EPOCHS = 10
BATCH_SIZE = 32
LR = 3e-4
DEVICE = "cuda" if torch.cuda.is_available() else "cpu"

train_transform = transforms.Compose([
    transforms.Resize((224, 224)),
    transforms.RandomHorizontalFlip(),
    transforms.RandomRotation(15),
    transforms.ToTensor(),
    transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225]),
])
val_transform = transforms.Compose([
    transforms.Resize((224, 224)),
    transforms.ToTensor(),
    transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225]),
])


def main():
    train_ds = datasets.ImageFolder(f"{DATA_DIR}/train", transform=train_transform)
    val_ds = datasets.ImageFolder(f"{DATA_DIR}/val", transform=val_transform)
    class_names = train_ds.classes
    print("Classes:", class_names)

    train_loader = DataLoader(train_ds, batch_size=BATCH_SIZE, shuffle=True, num_workers=2)
    val_loader = DataLoader(val_ds, batch_size=BATCH_SIZE, num_workers=2)

    model = models.efficientnet_b0(weights=models.EfficientNet_B0_Weights.DEFAULT)
    in_features = model.classifier[1].in_features
    model.classifier[1] = nn.Linear(in_features, len(class_names))
    model = model.to(DEVICE)

    criterion = nn.CrossEntropyLoss()
    optimizer = torch.optim.AdamW(model.parameters(), lr=LR)

    best_acc = 0.0
    for epoch in range(NUM_EPOCHS):
        model.train()
        running_loss = 0.0
        for imgs, labels in train_loader:
            imgs, labels = imgs.to(DEVICE), labels.to(DEVICE)
            optimizer.zero_grad()
            outputs = model(imgs)
            loss = criterion(outputs, labels)
            loss.backward()
            optimizer.step()
            running_loss += loss.item() * imgs.size(0)
        train_loss = running_loss / len(train_ds)

        model.eval()
        correct, total = 0, 0
        with torch.no_grad():
            for imgs, labels in val_loader:
                imgs, labels = imgs.to(DEVICE), labels.to(DEVICE)
                outputs = model(imgs)
                preds = outputs.argmax(1)
                correct += (preds == labels).sum().item()
                total += labels.size(0)
        val_acc = correct / total if total else 0
        print(f"Epoch {epoch+1}/{NUM_EPOCHS} | train_loss={train_loss:.4f} | val_acc={val_acc:.4f}")

        if val_acc > best_acc:
            best_acc = val_acc
            torch.save({"model_state": model.state_dict(), "classes": class_names}, "cotton_disease_model.pt")
            print("  -> saved new best model")

    print(f"Done. Best val accuracy: {best_acc:.4f}")
    print("Download cotton_disease_model.pt and load it in your FastAPI backend to replace the Claude-vision placeholder.")


if __name__ == "__main__":
    main()
