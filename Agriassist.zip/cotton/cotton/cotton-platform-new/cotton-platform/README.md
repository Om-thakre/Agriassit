# AgriAssist — Vidarbha Cotton Platform (local model version, no Gemini/API key)

This is your original project with the chatbot rebuilt to run entirely on your own
machine: **no Gemini, no API key, no per-call cost, no internet dependency at
inference time.** It uses a local open-source LLM + a domain knowledge base, which
also gives you a genuine novelty angle for your research report (see bottom).

---

## What changed vs. your original project

| File | Change |
|---|---|
| `backend/rag_chatbot.py` | **New.** Local Retrieval-Augmented Generation (RAG) pipeline: embeds your question, retrieves relevant chunks from `backend/knowledge_base/`, sends question + retrieved context to a local LLM (via Ollama). |
| `backend/knowledge_base/*.md` | **New.** Curated Vidarbha cotton advisory notes (sowing, irrigation, pest/disease, fertilizer, MSP/market) — this is the "grounding" data the chatbot is allowed to use. Expand this with real KVK/ICAR material for a stronger research contribution. |
| `backend/main.py` | `/api/chat` now calls `rag_chatbot.generate_reply()` instead of `google.generativeai`. `/api/disease` no longer calls Gemini vision — it uses your own trained CNN from `training/train_cnn.py` if present, and gives a clear message if you haven't trained it yet. `/api/yield` is unchanged (it never used Gemini). |
| `backend/requirements.txt` | Removed `google-generativeai`. Added `chromadb` (local vector store) and `sentence-transformers` (local embeddings). |
| `frontend/index.html` | **Unchanged.** It just calls `/api/chat` on your backend — it has no idea whether Gemini or a local model answers, so nothing to edit here. |

You no longer need a `GEMINI_API_KEY` anywhere.

---

## How it works (architecture)

```
Farmer question (Marathi/Hindi/English)
        │
        ▼
sentence-transformers multilingual embedding  ──►  Chroma vector search
        │                                           over knowledge_base/*.md
        ▼
Top-4 relevant chunks + chat history + system prompt
        │
        ▼
Local LLM (Ollama, e.g. llama3.2:3b) running on YOUR machine
        │
        ▼
Grounded reply back to the farmer
```

This is the same pattern production RAG chatbots use — the LLM is only allowed to
draw facts from the retrieved chunks, which is what keeps it from inventing prices
or scheme names.

---

## 1. Install Ollama (runs the LLM locally, free, no key)

1. Download from **https://ollama.com/download** (Windows/Mac/Linux all supported).
2. Install it — it starts a background service automatically (`ollama serve`).
3. Pull a small model (one-time download, then fully offline):
   ```bash
   ollama pull llama3.2:3b
   ```
   If your laptop is low on RAM (<8GB free), use the smaller/faster:
   ```bash
   ollama pull phi3:mini
   ```
   and set `OLLAMA_MODEL=phi3:mini` as an environment variable before starting the
   backend (see below), or edit the default in `rag_chatbot.py`.
4. Quick test: `ollama run llama3.2:3b` and type a message — if you get a reply,
   Ollama is working.

You only have GPU access via Colab/Kaggle, which is fine: these small models
(3B and under) run acceptably on a normal laptop CPU for a chatbot demo. Save your
Colab/Kaggle GPU hours for the disease-CNN training (`training/train_cnn.py`),
which actually benefits from GPU.

## 2. Run the backend

```bash
cd backend
python -m venv venv
```
Activate it:
- Mac/Linux: `source venv/bin/activate`
- Windows PowerShell: `venv\Scripts\activate`

```bash
pip install -r requirements.txt
uvicorn main:app --reload --host 0.0.0.0 --port 8000
```

First chat request will be a bit slow (building the vector index from
`knowledge_base/*.md` — happens once, then it's cached in `backend/chroma_store/`).

## 3. Open the frontend

Double-click `frontend/index.html`, same as before. Try the Chat tab.

If `/api/chat` returns a 503 error, it means Ollama isn't running or the model
isn't pulled yet — the error message tells you exactly which command to run.

---

## Extending it

- **Add more knowledge**: drop more `.md`/`.txt` files into `backend/knowledge_base/`
  with real KVK/ICAR advisory content (in English is fine — the multilingual
  embedding model retrieves correctly across languages). Delete the
  `backend/chroma_store/` folder so it rebuilds the index on next run.
- **Swap the LLM**: change `OLLAMA_MODEL` in `rag_chatbot.py` to any model you've
  pulled (`ollama pull mistral`, `ollama pull qwen2.5:3b`, etc.) — Qwen2.5 tends to
  handle Hindi/Marathi noticeably better than Llama if you want to compare.
- **Disease detection**: train `training/train_cnn.py` on Kaggle/Colab's free GPU
  on a cotton leaf disease dataset, download `cotton_disease_model.pt`, drop it in
  `backend/`, restart the server — `/api/disease` will pick it up automatically.

---

## Novelty angle for your research report

Swapping in a wrapped commercial API (Gemini/GPT) for another wrapped commercial API
isn't a research contribution by itself. What *is* a defensible, write-up-able
contribution here:

1. **Fully local, offline-capable inference.** No API dependency, no per-call cost,
   no data leaving the device — relevant for rural deployment where connectivity is
   unreliable and for farmer-data privacy. This is a real, citable design choice
   (edge/offline agri-advisory systems are an active research area).
2. **Domain-grounded RAG instead of raw LLM recall.** The chatbot is restricted to
   answering from a curated, region-specific knowledge base (Vidarbha black-soil
   agronomy) rather than the LLM's general training data, which measurably reduces
   hallucinated facts (prices, scheme names, dates) — you can *demonstrate and
   measure this* for your report (see below).
3. **Cross-lingual retrieval over an English knowledge base for Marathi/Hindi
   queries** — using a multilingual embedding model so a small, low-resource
   regional knowledge base still serves code-mixed Marathi-Hindi-English queries,
   which is a real research angle for low-resource Indian-language agri-assistants.

### Suggested evaluation for your report (turns this into measurable research, not just a build)
- Collect ~30-50 realistic farmer questions (sowing, irrigation, pest, MSP, etc.).
- Run them through (a) this local RAG system and (b) the LLM *without* retrieval
  (same model, same prompt, but skip the "Reference material" block).
- Have 2-3 people rate each answer for: factual grounding (did it stick to known
  facts vs. invent something), relevance, and language correctness.
- Report the RAG-vs-no-RAG hallucination/relevance difference as your key result —
  this is a standard, well-understood evaluation structure for RAG systems and is
  enough to justify novelty in a project report or paper.
- Optional stretch goal (needs your Colab/Kaggle GPU hours): fine-tune the
  embedding model or do a small LoRA fine-tune of the LLM on a farmer Q&A dataset
  you collect, and compare against the plain RAG baseline as a second experiment.
