@echo off
:: Kapus Mitra — Quick Start Script
:: Run this file to start the backend server

echo ============================================
echo   Kapus Mitra Backend — Starting...
echo ============================================

cd /d "%~dp0"

:: Check if .env has Plant.id key configured
findstr /C:"your_plant_id_api_key_here" .env >nul 2>&1
if %errorlevel% == 0 (
    echo.
    echo [WARNING] Plant.id API key is not configured!
    echo   Edit backend\.env and replace 'your_plant_id_api_key_here'
    echo   Get a free key at: https://web.plant.id
    echo   Disease detection will not work until the key is set.
    echo.
)

echo Starting FastAPI server on http://localhost:8000
echo API Docs available at: http://localhost:8000/docs
echo.
echo Press Ctrl+C to stop the server.
echo.

python -m uvicorn main:app --reload --host 0.0.0.0 --port 8000

pause
