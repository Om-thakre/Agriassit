"""
main.py — Kapus Mitra FastAPI Application v3

New in v3:
  - Lifespan startup: auto-detects Ollama model, warms it up, pre-loads vectors
  - Health check endpoints: /health, /health/chatbot, /health/weather, 
    /health/market, /health/disease, /health/schemes
  - Removed Plant.id integration completely
  - Disease endpoint returns rich structured data from local HF model
  - Language-aware chat (sends language to Ollama system prompt)
"""

import logging
from contextlib import asynccontextmanager
from typing import List, Optional

import httpx
from fastapi import FastAPI, File, HTTPException, Query, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

from config import settings, setup_logging
from services import disease_service, market_service, schemes_service

# ── Logging ───────────────────────────────────────────────────────────────────
logger = setup_logging()


# ── Lifespan: startup tasks ───────────────────────────────────────────────────
@asynccontextmanager
async def lifespan(app: FastAPI):
    """Run startup initialization before serving requests."""
    logger.info("=" * 60)
    logger.info("Kapus Mitra API v3 — Starting up")
    logger.info("=" * 60)

    # Initialize chatbot: detect model + warmup + load vectors
    try:
        import rag_chatbot
        rag_chatbot.initialize()
    except Exception as e:
        logger.error(f"Chatbot initialization error: {e}")

    logger.info("Server ready to accept requests.")
    logger.info("=" * 60)
    yield
    logger.info("Kapus Mitra API shutting down.")


# ── FastAPI App ───────────────────────────────────────────────────────────────
app = FastAPI(
    title="Kapus Mitra API",
    version="3.0",
    description=(
        "AI-powered Smart Agriculture Assistant for Vidarbha cotton farmers. "
        "Supports disease detection, chatbot advisory, market prices, and govt schemes."
    ),
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# ── Request/Response schemas ──────────────────────────────────────────────────

class ChatMessage(BaseModel):
    role: str       # "user" or "assistant"
    content: str


class ChatRequest(BaseModel):
    message: str
    history: List[ChatMessage] = []
    language: str = "mr"    # "mr"=Marathi, "hi"=Hindi, "en"=English


class YieldRequest(BaseModel):
    soil_moisture_pct: float = 55.0
    rainfall_mm: float = 600.0
    soil_ph: float = 7.0
    nitrogen_kg_ha: float = 80.0
    sowing_delay_days: int = 0


# ── Health Check Endpoints ────────────────────────────────────────────────────

@app.get("/health", tags=["health"])
async def health_overall():
    """Overall system health — checks all services."""
    import rag_chatbot
    chat_status = rag_chatbot.get_status()
    disease_status = disease_service.get_status()

    all_ok = (
        chat_status["status"] == "ok"
        and disease_status["status"] in ("ok", "degraded")  # degraded is acceptable
    )

    return {
        "status": "ok" if all_ok else "degraded",
        "version": "3.0",
        "services": {
            "chatbot": chat_status["status"],
            "disease": disease_status["status"],
            "market": "ok",
            "schemes": "ok",
            "weather": "external (open-meteo.com)",
        },
    }


@app.get("/health/chatbot", tags=["health"])
def health_chatbot():
    """Check Ollama connectivity and model availability."""
    try:
        import rag_chatbot
        return rag_chatbot.get_status()
    except Exception as e:
        return {"status": "error", "error": str(e)}


@app.get("/health/disease", tags=["health"])
def health_disease():
    """Check HuggingFace disease model status."""
    return disease_service.get_status()


@app.get("/health/market", tags=["health"])
async def health_market():
    """Check data.gov.in API reachability."""
    try:
        async with httpx.AsyncClient(timeout=5) as client:
            resp = await client.get(
                settings.DATA_GOV_IN_URL,
                params={"api-key": settings.DATA_GOV_IN_API_KEY, "format": "json", "limit": 1},
            )
        return {
            "status": "ok" if resp.status_code == 200 else "degraded",
            "api": "data.gov.in",
            "http_status": resp.status_code,
            "static_fallback": "available",
        }
    except Exception as e:
        return {
            "status": "degraded",
            "api": "data.gov.in",
            "error": str(e),
            "static_fallback": "available",
        }


@app.get("/health/weather", tags=["health"])
async def health_weather():
    """Check Open-Meteo API reachability."""
    try:
        async with httpx.AsyncClient(timeout=5) as client:
            resp = await client.get(
                "https://api.open-meteo.com/v1/forecast",
                params={"latitude": 21.14, "longitude": 79.09, "current": "temperature_2m"},
            )
        return {
            "status": "ok" if resp.status_code == 200 else "degraded",
            "api": "api.open-meteo.com",
            "http_status": resp.status_code,
        }
    except Exception as e:
        return {"status": "error", "api": "api.open-meteo.com", "error": str(e)}


@app.get("/health/schemes", tags=["health"])
def health_schemes():
    """Check government schemes service."""
    schemes = schemes_service.get_all_schemes()
    return {
        "status": "ok",
        "scheme_count": len(schemes),
        "scheme_ids": [s["id"] for s in schemes],
    }


# ── Main API Endpoints ────────────────────────────────────────────────────────

@app.get("/", tags=["general"])
def root():
    """Root health check."""
    import rag_chatbot
    status = rag_chatbot.get_status()
    return {
        "status": "ok",
        "service": "Kapus Mitra API v3.0",
        "ollama_model": status.get("active_model") or "not loaded",
        "disease_model": settings.HF_DISEASE_MODEL,
        "docs": "/docs",
    }


@app.post("/api/chat", tags=["chatbot"])
def chat(req: ChatRequest):
    """
    Language-aware agricultural chatbot via local Ollama.
    Supports Marathi (mr), Hindi (hi), English (en).
    """
    try:
        import rag_chatbot
    except ImportError:
        raise HTTPException(
            status_code=503,
            detail="Chatbot module not available. Check backend logs.",
        )

    if len(req.message.strip()) == 0:
        raise HTTPException(status_code=400, detail="Message cannot be empty.")

    try:
        history_dicts = [m.model_dump() for m in req.history]
        reply = rag_chatbot.generate_reply(
            req.message.strip(),
            history_dicts,
            language=req.language,
        )
        return {"reply": reply, "language": req.language}

    except RuntimeError as e:
        logger.error(f"Chat RuntimeError: {e}")
        raise HTTPException(status_code=503, detail=str(e))
    except Exception as e:
        logger.exception("Unexpected chat error")
        raise HTTPException(status_code=500, detail=f"Unexpected error: {e}")


@app.post("/api/disease", tags=["disease"])
async def detect_disease(image: UploadFile = File(...)):
    """
    Detect crop disease from uploaded image using local HuggingFace model.
    No external API key required. Returns comprehensive diagnostic report.
    """
    logger.info(
        f"Disease detection: filename={image.filename}, "
        f"content_type={image.content_type}"
    )

    if not image.content_type or not image.content_type.startswith("image/"):
        raise HTTPException(
            status_code=400,
            detail="Please upload a valid image file (JPG, PNG, WEBP).",
        )

    try:
        image_bytes = await image.read()
        result = await disease_service.detect_disease(
            image_bytes, image.filename or "image.jpg"
        )
        return result

    except ValueError as e:
        # Validation / setup errors — user-friendly 400
        logger.warning(f"Disease validation error: {e}")
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.exception("Unexpected disease detection error")
        raise HTTPException(
            status_code=500,
            detail=(
                f"Disease detection failed: {e}. "
                "Check backend logs or describe symptoms to the chatbot."
            ),
        )


@app.get("/api/market-prices", tags=["market"])
async def market_prices(
    crop: Optional[str] = Query(None, description="Crop: cotton, tur, soybean, wheat, gram, maize"),
    state: Optional[str] = Query(None, description="State: Maharashtra, Punjab, etc."),
    district: Optional[str] = Query(None, description="District: Yavatmal, Akola, etc."),
):
    """
    Fetch mandi prices from data.gov.in with curated static fallback.
    Always returns data — live if available, static reference prices otherwise.
    """
    logger.info(f"Market prices: crop={crop}, state={state}, district={district}")
    try:
        result = await market_service.get_market_prices(crop, state, district)
        return result
    except Exception as e:
        logger.error(f"Market error: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/api/government-schemes", tags=["schemes"])
def get_schemes(
    search: Optional[str] = Query(None, description="Search keyword e.g. pm-kisan, pmfby"),
):
    """Return all government schemes with full details."""
    try:
        if search:
            schemes = schemes_service.search_schemes(search)
        else:
            schemes = schemes_service.get_all_schemes()
        return {"schemes": schemes, "count": len(schemes)}
    except Exception as e:
        logger.error(f"Schemes error: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/api/government-schemes/{scheme_id}", tags=["schemes"])
def get_scheme(scheme_id: str):
    """Return full details for a single government scheme by ID."""
    scheme = schemes_service.get_scheme_by_id(scheme_id)
    if not scheme:
        valid_ids = [s["id"] for s in schemes_service.SCHEMES]
        raise HTTPException(
            status_code=404,
            detail=f"Scheme '{scheme_id}' not found. Valid IDs: {valid_ids}",
        )
    return scheme


