"""
rag_chatbot.py — Kapus Mitra AI Chatbot v3

Key improvements over v2:
  - AUTO-DETECTS best available Ollama model (no hardcoded model name)
  - Priority: llama3.2:3b → qwen2.5:3b → phi4-mini → gemma3:4b → any
  - 30-second response timeout (was 120s)
  - Streaming response collection
  - Model warm-up on startup
  - 2 retries with 2s delay before giving up
  - Language-aware responses (Marathi / Hindi / English)
  - RAG retrieval from local knowledge base (numpy-based, no C++ required)
"""

import glob
import logging
import os
import time

import numpy as np
import requests
from sentence_transformers import SentenceTransformer

from config import settings

logger = logging.getLogger(__name__)

# ── Paths ─────────────────────────────────────────────────────────────────────
KB_DIR = os.path.join(os.path.dirname(__file__), "knowledge_base")
STORE_PATH = os.path.join(os.path.dirname(__file__), "vector_store.npz")

# Multilingual embedding model (handles Marathi/Hindi/English queries)
EMBED_MODEL_NAME = "paraphrase-multilingual-MiniLM-L12-v2"

# ── Active model (resolved at startup) ────────────────────────────────────────
_active_model: str = ""
OLLAMA_BASE_URL = settings.OLLAMA_BASE_URL

# ── System prompt ─────────────────────────────────────────────────────────────
SYSTEM_PROMPT_BASE = """You are "Kapus Mitra" (AgriAssist / कपास मित्र), a friendly and expert agricultural assistant \
for farmers in the Vidarbha region of Maharashtra, India.

Your expertise covers:
- Cotton, Tur (Pigeon Pea), Soybean, Wheat, Gram, Maize cultivation
- Pest management and integrated pest control (IPM)
- Plant disease diagnosis and treatment
- Fertilizer recommendations (chemical and organic)
- Irrigation scheduling and water management
- Weather advisory and its impact on crops
- Live market prices and MSP (Minimum Support Price)
- Government schemes: PM-Kisan, PMFBY, PM-KUSUM, Kisan Credit Card, Soil Health Card, PMKSY
- Crop insurance guidance
- Soil health and soil testing
- Organic farming practices
- Best farming practices for Vidarbha's black cotton (regur) soil

Rules:
- Keep answers SHORT and PRACTICAL — farmers are busy. Max 4-5 sentences unless asked for detail.
- Use ONLY the reference material provided for specific prices, dates, or scheme details.
- If unsure, recommend contacting local KVK helpline: 1800-180-1551.
- Never invent specific prices, scheme benefits, or dates not in the reference material.
- When asked about disease, recommend using the Disease tab for photo-based diagnosis.
- When asked about market prices, recommend checking the Market tab for live prices.
"""

LANG_INSTRUCTIONS = {
    "mr": (
        "भाषा: फक्त सोप्या मराठीत उत्तर द्या. "
        "शेतकऱ्यांना समजेल असे बोला. हिंदी किंवा इंग्रजी टाळा."
    ),
    "hi": (
        "भाषा: केवल सरल हिंदी में उत्तर दें। "
        "किसानों के लिए व्यावहारिक भाषा उपयोग करें। अंग्रेज़ी शब्द कम रखें।"
    ),
    "en": (
        "Language: Reply in clear, practical English. "
        "Keep it concise — 3 to 5 sentences unless more detail is asked."
    ),
}

# ── In-memory vector store ────────────────────────────────────────────────────
_embed_model = None
_chunks = None
_sources = None
_embeddings = None


def _get_embed_model():
    global _embed_model
    if _embed_model is None:
        logger.info(f"Loading embedding model: {EMBED_MODEL_NAME}")
        _embed_model = SentenceTransformer(EMBED_MODEL_NAME)
    return _embed_model


def _chunk_text(text: str, max_chars: int = 900) -> list[str]:
    paragraphs = [p.strip() for p in text.split("\n\n") if p.strip()]
    chunks, current = [], ""
    for p in paragraphs:
        if len(current) + len(p) + 2 <= max_chars:
            current = f"{current}\n\n{p}" if current else p
        else:
            if current:
                chunks.append(current)
            current = p
    if current:
        chunks.append(current)
    return chunks


def _normalize(vecs: np.ndarray) -> np.ndarray:
    norms = np.linalg.norm(vecs, axis=1, keepdims=True)
    norms[norms == 0] = 1e-8
    return vecs / norms


def _build_index():
    global _chunks, _sources, _embeddings
    model = _get_embed_model()
    chunks, sources = [], []

    for path in sorted(glob.glob(os.path.join(KB_DIR, "*.md"))):
        source = os.path.basename(path)
        with open(path, "r", encoding="utf-8") as f:
            text = f.read()
        for chunk in _chunk_text(text):
            chunks.append(chunk)
            sources.append(source)

    if not chunks:
        _chunks, _sources, _embeddings = [], [], np.zeros((0, 384), dtype=np.float32)
        logger.warning("No knowledge base files found in knowledge_base/")
        return

    logger.info(f"Building vector index from {len(chunks)} chunks across {len(set(sources))} files")
    embeddings = model.encode(chunks, convert_to_numpy=True, show_progress_bar=False)
    embeddings = _normalize(embeddings.astype(np.float32))
    np.savez(STORE_PATH, embeddings=embeddings,
             chunks=np.array(chunks, dtype=object),
             sources=np.array(sources, dtype=object))
    _chunks, _sources, _embeddings = chunks, sources, embeddings
    logger.info("Vector index built and saved.")


def _load_index() -> bool:
    global _chunks, _sources, _embeddings
    if not os.path.exists(STORE_PATH):
        return False
    try:
        data = np.load(STORE_PATH, allow_pickle=True)
        _embeddings = data["embeddings"]
        _chunks = list(data["chunks"])
        _sources = list(data["sources"])
        logger.info(f"Loaded vector index: {len(_chunks)} chunks")
        return True
    except Exception as e:
        logger.warning(f"Failed to load vector store: {e}")
        return False


def _ensure_index():
    if _embeddings is not None:
        return
    if not _load_index():
        _build_index()


def retrieve(query: str, k: int = 4) -> list[dict]:
    """Return top-k relevant knowledge base chunks for a query."""
    _ensure_index()
    if not _chunks or _embeddings is None or len(_chunks) == 0:
        return []
    model = _get_embed_model()
    q_emb = model.encode([query], convert_to_numpy=True, show_progress_bar=False).astype(np.float32)
    q_emb = _normalize(q_emb)[0]
    scores = _embeddings @ q_emb
    top_idx = np.argsort(-scores)[:k]
    return [
        {"text": _chunks[i], "source": _sources[i], "score": float(scores[i])}
        for i in top_idx
        if float(scores[i]) > 0.2  # filter out irrelevant chunks
    ]


# ── Ollama model detection ────────────────────────────────────────────────────

def detect_best_model() -> str:
    """
    Auto-detect the best available Ollama model based on priority list.
    Returns the model name string or empty string if Ollama is unreachable.
    """
    try:
        resp = requests.get(
            f"{OLLAMA_BASE_URL}/api/tags",
            timeout=5
        )
        if resp.status_code != 200:
            logger.warning(f"Ollama /api/tags returned {resp.status_code}")
            return ""

        available = {m["name"] for m in resp.json().get("models", [])}
        # Also check base names without tag
        available_base = {m.split(":")[0] for m in available}

        logger.info(f"Ollama available models: {sorted(available)}")

        # Try preferred models in order
        for preferred in settings.OLLAMA_PREFERRED_MODELS:
            pbase = preferred.split(":")[0]
            if preferred in available:
                logger.info(f"Selected Ollama model: {preferred}")
                return preferred
            # Try base name with :latest tag
            if pbase in available_base:
                for m in available:
                    if m.startswith(pbase):
                        logger.info(f"Selected Ollama model: {m}")
                        return m

        # If no preferred model found, use first available
        if available:
            model = sorted(available)[0]
            logger.warning(f"No preferred model found. Using first available: {model}")
            return model

        logger.error("No Ollama models installed. Run: ollama pull llama3.2:3b")
        return ""

    except requests.exceptions.ConnectionError:
        logger.error(
            f"Cannot connect to Ollama at {OLLAMA_BASE_URL}. "
            "Start Ollama with: ollama serve"
        )
        return ""
    except Exception as e:
        logger.error(f"Ollama model detection failed: {e}")
        return ""


def warmup_model(model_name: str) -> bool:
    """
    Send a tiny prompt to warm up the model so first user request is fast.
    Returns True if warmup succeeded.
    """
    if not model_name:
        return False
    try:
        logger.info(f"Warming up model: {model_name} ...")
        resp = requests.post(
            f"{OLLAMA_BASE_URL}/api/chat",
            json={
                "model": model_name,
                "messages": [{"role": "user", "content": "Hello"}],
                "stream": False,
                "options": {"num_predict": 5},  # Very short response for warmup
            },
            timeout=60,  # Allow more time for first load into RAM
        )
        if resp.status_code == 200:
            logger.info(f"Model {model_name} warmed up successfully.")
            return True
        else:
            logger.warning(f"Warmup returned {resp.status_code}: {resp.text[:200]}")
            return False
    except requests.exceptions.Timeout:
        logger.warning(f"Model {model_name} warmup timed out — model may be loading. Continuing anyway.")
        return False
    except Exception as e:
        logger.warning(f"Model warmup failed: {e}")
        return False


def initialize():
    """
    Called at FastAPI startup. Detects Ollama model and warms it up.
    Also pre-loads the vector index.
    """
    global _active_model
    _active_model = detect_best_model()
    if _active_model:
        warmup_model(_active_model)
    # Pre-load embeddings
    _ensure_index()
    logger.info(f"RAG chatbot initialized. Active model: {_active_model or 'NONE'}")


# ── Main chat function ────────────────────────────────────────────────────────

def _call_ollama(model: str, messages: list, timeout: int = 30) -> str:
    """Call Ollama with retries. Returns the response text."""
    last_error = None
    for attempt in range(3):  # 3 attempts total
        try:
            resp = requests.post(
                f"{OLLAMA_BASE_URL}/api/chat",
                json={
                    "model": model,
                    "messages": messages,
                    "stream": False,
                    "options": {
                        "temperature": 0.7,
                        "num_predict": 512,  # Max tokens per response
                        "top_p": 0.9,
                    },
                },
                timeout=timeout,
            )

            if resp.status_code == 404:
                raise RuntimeError(
                    f"Model '{model}' not found in Ollama. "
                    f"Install it with: ollama pull {model}"
                )

            if resp.status_code != 200:
                raise RuntimeError(
                    f"Ollama returned HTTP {resp.status_code}: {resp.text[:300]}"
                )

            content = resp.json().get("message", {}).get("content", "")
            if not content:
                raise RuntimeError("Ollama returned empty response")

            return content

        except requests.exceptions.Timeout:
            last_error = RuntimeError(
                f"Ollama timed out after {timeout}s. "
                f"The model '{model}' may be loading or your hardware is slow. "
                "Try asking a simpler question."
            )
            logger.warning(f"Ollama timeout (attempt {attempt + 1}/3)")
            if attempt < 2:
                time.sleep(2)

        except requests.exceptions.ConnectionError:
            raise RuntimeError(
                f"Cannot connect to Ollama at {OLLAMA_BASE_URL}. "
                "Make sure Ollama is running: `ollama serve`"
            )

        except RuntimeError:
            raise

        except Exception as e:
            last_error = RuntimeError(f"Ollama request failed: {e}")
            if attempt < 2:
                time.sleep(2)

    raise last_error


def generate_reply(
    message: str,
    history: list[dict],
    language: str = "mr",
) -> str:
    """
    Generate a language-aware chatbot reply using local RAG + Ollama.

    Args:
        message:  Farmer's question (any language)
        history:  Conversation history [{role, content}, ...]
        language: "mr" (Marathi), "hi" (Hindi), "en" (English)

    Returns:
        Reply string in the specified language.
    """
    global _active_model

    # Refresh model if not set
    if not _active_model:
        _active_model = detect_best_model()

    if not _active_model:
        raise RuntimeError(
            "No Ollama models available. "
            "Install a model with: ollama pull llama3.2:3b\n"
            "Then start Ollama: ollama serve"
        )

    # Retrieve relevant knowledge base chunks
    hits = retrieve(message, k=4)
    if hits:
        context_parts = [f"[{h['source']}]\n{h['text']}" for h in hits]
        context_block = "\n\n---\n\n".join(context_parts)
    else:
        context_block = "(No specific reference material found for this question.)"

    # Build language-specific system prompt
    lang_instr = LANG_INSTRUCTIONS.get(language, LANG_INSTRUCTIONS["mr"])
    full_system = f"{SYSTEM_PROMPT_BASE}\n{lang_instr}"

    # Build message array
    messages = [{"role": "system", "content": full_system}]

    # Add last 6 turns of history
    for turn in history[-6:]:
        role = "assistant" if turn.get("role") == "assistant" else "user"
        content = turn.get("content", "").strip()
        if content:
            messages.append({"role": role, "content": content})

    # Add current question with context
    messages.append({
        "role": "user",
        "content": (
            f"Reference material:\n{context_block}\n\n"
            f"Question: {message}"
        ),
    })

    logger.info(
        f"Chat request: model={_active_model}, lang={language}, "
        f"msg_len={len(message)}, history_turns={len(history)}"
    )
    return _call_ollama(_active_model, messages, timeout=settings.OLLAMA_TIMEOUT)


def get_status() -> dict:
    """Return current chatbot status for health check endpoint."""
    global _active_model
    ollama_ok = False
    available_models = []

    try:
        resp = requests.get(f"{OLLAMA_BASE_URL}/api/tags", timeout=3)
        if resp.status_code == 200:
            ollama_ok = True
            available_models = [m["name"] for m in resp.json().get("models", [])]
    except Exception:
        pass

    return {
        "ollama_url": OLLAMA_BASE_URL,
        "ollama_reachable": ollama_ok,
        "active_model": _active_model or None,
        "available_models": available_models,
        "knowledge_base_chunks": len(_chunks) if _chunks else 0,
        "status": "ok" if (ollama_ok and _active_model) else "degraded",
    }
