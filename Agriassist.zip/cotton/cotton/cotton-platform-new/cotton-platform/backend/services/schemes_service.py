"""
schemes_service.py — Government Agricultural Schemes for Farmers

Provides a comprehensive, structured list of 8 major central government
schemes relevant to Indian farmers (especially Vidarbha cotton farmers).

Data sourced from official government portals (verified July 2026):
  - pmkisan.gov.in
  - pmfby.gov.in
  - pmkusum.mnre.gov.in
  - soilhealth.dac.gov.in
  - pmksy.gov.in
  - agriinfra.dac.gov.in
  - enam.gov.in
  - kcc.gov.in (via NaBFID/RBI)

No external API needed — data is always available.
"""

from typing import Optional

SCHEMES: list[dict] = [
    {
        "id": "pm-kisan",
        "name": "PM-KISAN (Pradhan Mantri Kisan Samman Nidhi)",
        "emoji": "💰",
        "description": (
            "PM-KISAN provides direct income support of ₹6,000 per year to all landholding "
            "farmer families across India. The amount is released in three equal installments "
            "of ₹2,000 directly into farmers' bank accounts via DBT (Direct Benefit Transfer)."
        ),
        "benefits": [
            "₹6,000 per year (₹2,000 every 4 months) directly to bank account",
            "No intermediary — direct bank transfer (DBT)",
            "Covers all landholding farmer families",
            "No deduction from income tax benefits",
        ],
        "eligibility": [
            "All landholding farmer families with cultivable land",
            "Must be a citizen of India",
            "Small and marginal farmers as well as large farmers are eligible",
            "Family must not include any government employee, income tax payer, or professional",
            "Must have Aadhaar card linked to bank account",
        ],
        "documents": [
            "Aadhaar Card (mandatory)",
            "Bank account details (passbook copy)",
            "Land ownership documents (7/12 extract in Maharashtra)",
            "Mobile number linked to Aadhaar",
        ],
        "how_to_apply": (
            "1. Visit pmkisan.gov.in → 'Farmers Corner' → 'New Farmer Registration'\n"
            "2. Enter Aadhaar number, bank details, and land records\n"
            "3. OR visit your nearest Common Service Centre (CSC) / e-Mitra centre\n"
            "4. Registration can also be done via local Patwari/Lekhpal"
        ),
        "website": "https://pmkisan.gov.in",
        "helpline": "155261 / 011-23381092",
        "deadline": "Open throughout the year (no fixed deadline)",
        "tags": ["income support", "cash transfer", "all farmers", "aadhaar"],
    },
    {
        "id": "pm-fasal-bima",
        "name": "PM Fasal Bima Yojana (PMFBY)",
        "emoji": "🌾",
        "description": (
            "Pradhan Mantri Fasal Bima Yojana is a crop insurance scheme providing financial "
            "support to farmers suffering crop loss/damage due to unforeseen events like natural "
            "calamities, pests, and diseases. Premium is heavily subsidized by central and state government."
        ),
        "benefits": [
            "Crop loss compensation for natural calamities, drought, flood, cyclone",
            "Very low premium: 2% for Kharif crops, 1.5% for Rabi crops, 5% for horticulture",
            "Full sum insured (no capping) with latest technology for quick claim settlement",
            "Post-harvest losses and localized calamities also covered",
            "Use of satellite imagery, drones, and smartphones for loss assessment",
        ],
        "eligibility": [
            "All farmers growing notified crops in notified areas",
            "Both loanee farmers (auto-enrolled via KCC) and non-loanee farmers can apply",
            "Tenant/sharecropper farmers are also eligible",
            "Must apply before cut-off date for that season",
        ],
        "documents": [
            "Aadhaar Card",
            "Bank account details",
            "7/12 land record / ROR (Record of Rights)",
            "Sowing certificate from Gram Panchayat/Patwari",
            "For tenant farmers: rent agreement or proof of cultivation",
        ],
        "how_to_apply": (
            "1. Visit pmfby.gov.in → Farmer login → New enrollment\n"
            "2. Loanee farmers: automatically enrolled via their crop loan/KCC at bank\n"
            "3. Non-loanee farmers: visit nearest bank branch, CSC, or insurance company office\n"
            "4. Can also apply via PMFBY app (available on Google Play)"
        ),
        "website": "https://pmfby.gov.in",
        "helpline": "1800-200-7710 (Toll-free) / 14447",
        "deadline": "Kharif: July 31; Rabi: December 31 (varies by state/district)",
        "tags": ["crop insurance", "kharif", "rabi", "cotton", "disaster", "loss compensation"],
    },
    {
        "id": "pm-kusum",
        "name": "PM-KUSUM (Pradhan Mantri Kisan Urja Suraksha evam Utthaan Mahabhiyan)",
        "emoji": "☀️",
        "description": (
            "PM-KUSUM scheme aims to add solar power capacity of 30.8 GW by 2026. It enables "
            "farmers to set up solar pumps for irrigation, install solar power plants on barren land, "
            "and solarise existing grid-connected pumps — reducing electricity costs and increasing income."
        ),
        "benefits": [
            "Component A: 10 MW solar power plants on barren/agricultural land — sell power to DISCOMs",
            "Component B: 7.5 HP standalone solar pumps at 30% farmer cost (60% subsidy from govt, 30% loan)",
            "Component C: Solarisation of existing grid-connected pumps — 30% subsidy",
            "Assured income from solar power generation",
            "Reduction in diesel/electricity cost for irrigation",
        ],
        "eligibility": [
            "Individual farmers, farmer groups, FPOs, cooperatives",
            "Must have land for Component A (minimum 0.5 acres)",
            "For Components B & C: farmer must have irrigation pump",
            "Priority to water-stressed areas and dark zone regions",
        ],
        "documents": [
            "Aadhaar Card",
            "Land ownership documents",
            "Bank account details",
            "Existing electricity bill (for Component C)",
            "Application form from state DISCOM/MNRE nodal agency",
        ],
        "how_to_apply": (
            "1. Visit pmkusum.mnre.gov.in\n"
            "2. Apply through your state's DISCOM or MNRE nodal agency\n"
            "3. In Maharashtra: apply via MSEDCL (msedcl.in) or district agriculture office\n"
            "4. Contact: National nodal agency MNRE / State Renewable Energy Development Agency (SEDA)"
        ),
        "website": "https://pmkusum.mnre.gov.in",
        "helpline": "1800-180-3333 (MNRE)",
        "deadline": "Ongoing — apply through respective state agency",
        "tags": ["solar pump", "solar energy", "irrigation", "renewable", "electricity subsidy"],
    },
    {
        "id": "soil-health-card",
        "name": "Soil Health Card Scheme (SHC)",
        "emoji": "🌱",
        "description": (
            "The Soil Health Card scheme provides every farmer a Soil Health Card every 2 years "
            "showing 12 key soil parameters with crop-wise fertilizer recommendations. This helps "
            "farmers use appropriate fertilizers, reduce costs, and improve soil health."
        ),
        "benefits": [
            "Free soil testing at government soil testing labs",
            "Soil Health Card with 12 parameters: N, P, K, pH, EC, OC, Zn, Fe, Cu, Mn, Bo, S",
            "Crop-specific fertilizer and micro-nutrient recommendations",
            "Reduces over-use of fertilizers — saves cost by ₹2,000–5,000/acre",
            "Improves crop yield by 10–15% through balanced nutrition",
        ],
        "eligibility": [
            "All farmers across India",
            "Applies to all crops: cotton, tur, soybean, wheat, gram, maize, horticulture",
        ],
        "documents": [
            "Aadhaar Card",
            "7/12 land record / land ownership proof",
            "Soil sample (collected by agriculture department or farmer)",
        ],
        "how_to_apply": (
            "1. Visit soilhealth.dac.gov.in to view your existing card (enter Aadhaar or mobile)\n"
            "2. Contact your district agriculture officer for new soil sample collection\n"
            "3. OR visit your nearest Krishi Vigyan Kendra (KVK) or agriculture department office\n"
            "4. Farmers can also request sample collection via the Soil Health Card mobile app"
        ),
        "website": "https://soilhealth.dac.gov.in",
        "helpline": "Contact district Agriculture Department / KVK",
        "deadline": "Samples collected every 2 years; open throughout the year",
        "tags": ["soil testing", "fertilizer", "soil health", "free service", "all crops"],
    },
    {
        "id": "kisan-credit-card",
        "name": "Kisan Credit Card (KCC)",
        "emoji": "💳",
        "description": (
            "Kisan Credit Card provides farmers with timely and adequate credit for agricultural "
            "needs including cultivation, post-harvest expenses, allied activities like animal "
            "husbandry and fisheries. Interest subvention makes it one of the cheapest farm loans "
            "available (effective rate as low as 4% per annum)."
        ),
        "benefits": [
            "Credit limit up to ₹3 lakh at 7% interest (4% after 3% subvention for timely repayment)",
            "Revolving credit — draw and repay as needed like a current account",
            "Covers crop cultivation, post-harvest, farm maintenance, and allied activities",
            "No collateral required up to ₹1.6 lakh",
            "Crop insurance coverage included (PMFBY auto-linked)",
            "Personal accident insurance cover of ₹50,000",
        ],
        "eligibility": [
            "All farmers — individual/joint borrowers, tenant farmers, SHGs",
            "Must have land ownership or lease agreement for cultivation",
            "Good credit history (no default on previous agricultural loans)",
        ],
        "documents": [
            "Aadhaar Card + PAN Card (or any government ID)",
            "7/12 land record / proof of cultivation",
            "Passport-size photographs (2)",
            "Bank account (any nationalised or cooperative bank)",
            "Caste certificate (for SC/ST farmers — additional subsidy)",
        ],
        "how_to_apply": (
            "1. Visit nearest nationalized bank, cooperative bank, or RRB branch\n"
            "2. Apply online via banks' internet banking portals (SBI, Bank of Maharashtra etc.)\n"
            "3. PM-Kisan beneficiaries get pre-approved KCC — check pmkisan.gov.in\n"
            "4. KCC Saturation Drive: special camps held by banks — watch for local announcements"
        ),
        "website": "https://www.nabard.org/content.aspx?id=572",
        "helpline": "1800-180-1551 (NABARD Toll-free)",
        "deadline": "Open throughout the year",
        "tags": ["loan", "credit", "interest subsidy", "working capital", "crop loan"],
    },
    {
        "id": "enam",
        "name": "eNAM (Electronic National Agriculture Market)",
        "emoji": "📊",
        "description": (
            "eNAM is a pan-India electronic trading portal that networks existing APMC mandis to "
            "create a unified national market for agricultural commodities. Farmers can sell their "
            "produce online to buyers across India, getting better prices through transparent bidding."
        ),
        "benefits": [
            "Transparent price discovery through competitive online bidding",
            "Access to buyers across India — not limited to local mandi",
            "Better price realization: typically 5–10% higher than traditional auctions",
            "Real-time price information on your mobile",
            "Single license valid across all eNAM mandis in the state",
            "Assaying (quality testing) at mandi for fair grading",
        ],
        "eligibility": [
            "All farmers registered with their local APMC mandi",
            "Must have bank account (for payment)",
            "Must have mobile number for OTP-based login",
        ],
        "documents": [
            "Aadhaar Card",
            "Bank account details (IFSC + account number)",
            "Mobile number",
            "Local mandi/APMC farmer registration",
        ],
        "how_to_apply": (
            "1. Visit enam.gov.in → Farmer Registration\n"
            "2. Register at your nearest eNAM-enabled APMC mandi (1000+ mandis across India)\n"
            "3. Download eNAM app from Google Play Store\n"
            "4. In Maharashtra: eNAM mandis at Nagpur, Yavatmal, Amravati, Akola, Pune, etc."
        ),
        "website": "https://enam.gov.in",
        "helpline": "1800-270-0224 (Toll-free)",
        "deadline": "Open throughout the year",
        "tags": ["market", "price", "sell online", "trading", "mandi", "better price"],
    },
    {
        "id": "pm-krishi-sinchai",
        "name": "PM Krishi Sinchai Yojana (PMKSY)",
        "emoji": "💧",
        "description": (
            "PMKSY aims to achieve 'Har Khet Ko Pani' (water to every farm) and 'More Crop Per Drop' "
            "by improving water use efficiency through micro-irrigation (drip and sprinkler systems) "
            "and watershed development. Critical for rain-fed Vidarbha farmers."
        ),
        "benefits": [
            "Drip irrigation subsidy: 45–55% for small/marginal farmers (up to 90% in some states)",
            "Sprinkler irrigation subsidy: 50–55% for small/marginal farmers",
            "Per Drop More Crop: supports micro-irrigation system installation",
            "Har Khet Ko Pani: canal extension, groundwater development",
            "Watershed development for dryland farming areas (Vidarbha benefit)",
        ],
        "eligibility": [
            "All categories of farmers — small, marginal, and large",
            "Higher subsidy for SC/ST farmers and women farmers",
            "Must have own land or long-term lease (minimum 7 years)",
            "Farmer must invest own share first; subsidy released afterwards",
        ],
        "documents": [
            "Aadhaar Card",
            "7/12 land record",
            "Bank account details",
            "Quotation from approved drip/sprinkler vendor",
            "Application to district agriculture office",
        ],
        "how_to_apply": (
            "1. Visit pmksy.gov.in for scheme details\n"
            "2. Apply through your district agriculture office\n"
            "3. In Maharashtra: apply via MahaDBT Shetkari portal at mahadbt.maharashtra.gov.in\n"
            "4. Contact your Taluka Agriculture Officer (TAO) for registration"
        ),
        "website": "https://pmksy.gov.in",
        "helpline": "1800-180-1551 / Contact district Agriculture Department",
        "deadline": "Apply as per state government's annual schedule",
        "tags": ["drip irrigation", "sprinkler", "water", "subsidy", "micro-irrigation"],
    },
    {
        "id": "agri-infra-fund",
        "name": "Agriculture Infrastructure Fund (AIF)",
        "emoji": "🏭",
        "description": (
            "The Agriculture Infrastructure Fund is a financing facility of ₹1 lakh crore for "
            "investment in post-harvest management infrastructure and community farming assets. "
            "It provides medium-to-long-term credit with interest subvention and credit guarantee "
            "for viable projects like warehouses, cold chains, primary processing."
        ),
        "benefits": [
            "3% interest subvention on loans up to ₹2 crore",
            "Credit Guarantee support via CGTMSE for loans up to ₹2 crore",
            "Loan for: cold storage, warehouses, primary processing, sorting/grading, silos",
            "Maximum repayment period: 7 years (including moratorium)",
            "Open to FPOs, SHGs, cooperatives, individual entrepreneurs and farmers",
        ],
        "eligibility": [
            "Farmer Producer Organisations (FPOs)",
            "Self Help Groups (SHGs), Cooperatives",
            "Individual farmers and agri-entrepreneurs",
            "Startups working in agriculture post-harvest space",
            "APMC bodies and multipurpose cooperative societies",
        ],
        "documents": [
            "Business Plan / Project Report (DPR)",
            "Aadhaar / Company registration documents",
            "Land ownership documents / lease agreement",
            "3 years bank statements (for existing entities)",
            "Quotations from machinery/construction vendors",
        ],
        "how_to_apply": (
            "1. Visit agriinfra.dac.gov.in → Apply Now\n"
            "2. Select implementing agency (bank branch near you)\n"
            "3. Submit DPR (Detailed Project Report) along with loan application\n"
            "4. Contact your nearest NABARD / nationalized bank branch for guidance"
        ),
        "website": "https://agriinfra.dac.gov.in",
        "helpline": "1800-11-1526 (NABARD) / Contact nearest bank",
        "deadline": "Scheme valid until 2032–33 (ongoing)",
        "tags": ["warehouse", "cold storage", "FPO", "loan", "post-harvest", "infrastructure"],
    },
]

# Build a fast lookup by ID
_SCHEME_INDEX: dict[str, dict] = {s["id"]: s for s in SCHEMES}


def get_all_schemes() -> list[dict]:
    """Return all government schemes."""
    return SCHEMES


def get_scheme_by_id(scheme_id: str) -> Optional[dict]:
    """Return a single scheme by its ID, or None if not found."""
    return _SCHEME_INDEX.get(scheme_id)


def search_schemes(query: str) -> list[dict]:
    """
    Search schemes by keyword (matches name, description, tags, benefits).
    Handles multi-word queries by scoring each individual word.
    Used by the chatbot to answer scheme-related questions.
    """
    words = query.lower().split()
    results = []
    for scheme in SCHEMES:
        score = 0
        name_lower = scheme["name"].lower()
        desc_lower = scheme["description"].lower()
        tags = [t.lower() for t in scheme.get("tags", [])]
        benefits_text = " ".join(scheme.get("benefits", [])).lower()

        for word in words:
            if len(word) < 3:
                continue  # skip very short words
            if word in name_lower:
                score += 3
            if word in desc_lower:
                score += 2
            if any(word in tag for tag in tags):
                score += 2
            if word in benefits_text:
                score += 1

        if score > 0:
            results.append((score, scheme))

    results.sort(key=lambda x: -x[0])
    return [s for _, s in results]
