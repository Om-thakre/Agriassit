"""
disease_service.py — Local Plant Disease Detection v3

Uses HuggingFace Vision Transformer (ViT) model trained on plant disease images.
No external API. No API key. Works 100% locally after first download.

Model: linkanjarad/plant-disease-detection-ViT-base
  - 38 disease/healthy classes for Cotton, Wheat, Tomato, Corn, Potato, etc.
  - Download: ~350MB (cached at ~/.cache/huggingface/ after first run)
  - CPU inference: 3-8 seconds per image

Fallback: If HF model unavailable → local disease encyclopedia (instant)
"""

import io
import logging
import os
from typing import Optional

from PIL import Image

from config import settings

logger = logging.getLogger(__name__)

# ── HuggingFace model (lazy-loaded on first request) ──────────────────────────
_hf_pipeline = None
_hf_load_attempted = False
_hf_available = False

# ── Complete Disease Encyclopedia ─────────────────────────────────────────────
# Used to enrich HF predictions AND as standalone fallback
DISEASE_ENCYCLOPEDIA: dict[str, dict] = {
    # ── Cotton diseases ──────────────────────────────────────────────────────
    "cotton leaf curl": {
        "display_name": "Cotton Leaf Curl Disease",
        "crop": "Cotton",
        "description": "A viral disease caused by Cotton Leaf Curl Virus (CLCuV), transmitted by whitefly. One of the most destructive cotton diseases in South Asia.",
        "symptoms": "Upward or downward curling of leaves, leaf thickening, yellowing (chlorosis), enations on leaf undersides, stunted plant growth, reduced boll setting.",
        "cause": "Cotton Leaf Curl Virus (CLCuV) — a geminivirus transmitted by whitefly (Bemisia tabaci). Hot dry conditions favor whitefly populations.",
        "severity": "High — can cause 30-70% yield loss if not controlled early.",
        "prevention": "Use resistant BT/CLCuV-resistant varieties. Remove infected plants immediately. Control whitefly populations early in season.",
        "pesticide": "Imidacloprid (Confidor 200 SL) 0.3 ml/litre; Thiamethoxam (Actara 25 WG) 0.3 g/litre; Acetamiprid 0.2 g/litre.",
        "organic_treatment": "Neem Seed Kernel Extract (NSKE) 5% spray; yellow sticky traps (10/acre); reflective silver mulch; spray Verticillium lecanii bioagent.",
        "farming_advice": "Scout fields weekly during June-August. Remove and burn infected plants. Avoid planting near sugarcane which hosts whitefly.",
    },
    "powdery mildew": {
        "display_name": "Powdery Mildew",
        "crop": "Multiple Crops",
        "description": "Fungal disease characterized by white powdery growth on plant surfaces. Common in cotton, wheat, and pulses during cool humid conditions.",
        "symptoms": "White powdery spots on leaves and stems, distorted young growth, yellowing, premature leaf drop, reduced photosynthesis.",
        "cause": "Fungal pathogens (Erysiphe spp., Leveillula taurica). Favored by warm days (25-30°C), cool nights, moderate humidity (50-70%).",
        "severity": "Medium — significant yield reduction if left untreated.",
        "prevention": "Good air circulation. Avoid excessive nitrogen. Crop rotation. Use resistant varieties. Remove crop debris after harvest.",
        "pesticide": "Sulfur 80 WP (Sulfex) 2.5 g/litre; Hexaconazole (Contaf 5 EC) 1 ml/litre; Propiconazole (Tilt 25 EC) 1 ml/litre; Tebuconazole 1 g/litre.",
        "organic_treatment": "Neem oil 5 ml/litre water; potassium bicarbonate 5 g/litre; milk solution (1 part milk: 9 parts water); baking soda 5 g/litre + oil 2 ml/litre.",
        "farming_advice": "Spray preventively at first sign. Avoid spraying during midday heat. Alternate fungicides to prevent resistance.",
    },
    "boll rot": {
        "display_name": "Cotton Boll Rot",
        "crop": "Cotton",
        "description": "A complex disease where cotton bolls rot before fully opening, caused by multiple fungal and bacterial pathogens entering through wounds.",
        "symptoms": "Soft, water-soaked bolls turning brown or black. Premature boll opening. Fluffy rotted lint. White or black fungal growth inside bolls.",
        "cause": "Fusarium, Diplodia, Xanthomonas, and other pathogens. Entry through insect feeding wounds, especially by bollworm, or through hail damage.",
        "severity": "High — directly destroys harvested cotton fiber.",
        "prevention": "Control bollworm early. Avoid waterlogging. Use certified disease-free seed. Ensure good field drainage. Avoid excessive nitrogen.",
        "pesticide": "Copper oxychloride (Blitox 50) 3 g/litre; Mancozeb (Indofil M-45) 2.5 g/litre; Carbendazim (Bavistin) 1 g/litre.",
        "organic_treatment": "Trichoderma viride 5 g/litre spray; Pseudomonas fluorescens 10 g/litre foliar spray; remove and destroy infected bolls.",
        "farming_advice": "Harvest partially opened bolls early in heavily infected fields. Ensure proper spacing for air circulation.",
    },
    "alternaria leaf spot": {
        "display_name": "Alternaria Leaf Spot",
        "crop": "Cotton / Multiple Crops",
        "description": "Fungal disease causing circular brown spots with yellow halos on leaves, leading to severe defoliation if left untreated.",
        "symptoms": "Brown circular spots (2-15mm diameter) with concentric rings and yellow halos on leaves. Severe defoliation. Spots may merge to cover large areas.",
        "cause": "Alternaria macrospora (cotton), A. alternata. Spread by wind and rain splash. Favored by warm (25-30°C) humid conditions.",
        "severity": "Medium to High — causes significant defoliation affecting yield.",
        "prevention": "Crop rotation. Avoid excessive nitrogen. Remove and burn crop debris after harvest. Maintain proper plant spacing.",
        "pesticide": "Mancozeb 75 WP (Indofil M-45) 2 g/litre; Iprodione (Rovral 50 WP) 2 g/litre; Chlorothalonil (Kavach) 2 g/litre.",
        "organic_treatment": "Neem oil 3 ml/litre; Copper hydroxide (Blue Shield) 3 g/litre; Trichoderma viride foliar spray.",
        "farming_advice": "Start preventive spraying at flowering stage. Maintain 2-3 spray schedule at 15-day intervals.",
    },
    "bacterial blight": {
        "display_name": "Bacterial Blight (Angular Leaf Spot)",
        "crop": "Cotton",
        "description": "Serious bacterial disease of cotton causing water-soaked angular spots on leaves, stem cankers, and boll lesions.",
        "symptoms": "Water-soaked angular spots on leaves (limited by leaf veins). Spots turn brown/black. Dark brown lesions on stems and bolls. Wilting. Premature defoliation.",
        "cause": "Xanthomonas axonopodis pv. malvacearum. Spread through infected seed, rain splash, and farm equipment. Cool wet conditions favor infection.",
        "severity": "High — seed transmission makes it difficult to eradicate.",
        "prevention": "Use certified disease-free seed. Seed treatment mandatory. Avoid overhead irrigation. Destroy infected crop debris.",
        "pesticide": "Streptocycline 100 ppm + Copper oxychloride 3 g/litre; Blitox-50 (copper oxychloride) 3 g/litre alone.",
        "organic_treatment": "Pseudomonas fluorescens seedling dip (10 g/litre for 30 min). Remove and burn infected plant parts.",
        "farming_advice": "Use hot water seed treatment (52°C for 30 min) before sowing. Never save seed from infected fields.",
    },
    "fusarium wilt": {
        "display_name": "Fusarium Wilt",
        "crop": "Cotton / Tur / Multiple Crops",
        "description": "Soil-borne fungal disease that blocks water conduction in plants, causing sudden wilting and plant death. Persists in soil for years.",
        "symptoms": "Yellowing of lower leaves progressing upward. Brown vascular discoloration when stem cut open. Wilting of entire plant. Plant death. Roots turn brown.",
        "cause": "Fusarium oxysporum f.sp. vasinfectum (cotton), F. udum (tur). Soil-borne; favors acidic soils and poor drainage.",
        "severity": "Very High — soil-borne and long-lasting; no chemical cure once infected.",
        "prevention": "Use resistant varieties (CICR released wilt-resistant cotton). Crop rotation with sorghum/maize. Soil solarization in May-June. Balanced nutrition.",
        "pesticide": "Carbendazim (Bavistin) 1 g/litre soil drench; Thiophanate methyl (Topsin M) 1 g/litre. Preventive only — no cure once wilted.",
        "organic_treatment": "Trichoderma harzianum 5 g/kg seed treatment. Trichoderma + FYM incorporation in soil (2 kg Trichoderma per acre with 500 kg FYM). Neem cake application.",
        "farming_advice": "Uproot and burn severely infected plants. Avoid waterlogging. Do not replant cotton/tur in affected plots for 2-3 years.",
    },
    "bollworm": {
        "display_name": "Bollworm Infestation",
        "crop": "Cotton",
        "description": "Major pest complex including American bollworm (Helicoverpa), Pink bollworm (Pectinophora), and Spotted bollworm that damage cotton bolls and buds.",
        "symptoms": "Entry holes in squares and bolls. Frass (excreta) visible near entry holes. Premature shedding of squares and small bolls. Damaged bolls with internal feeding.",
        "cause": "Helicoverpa armigera (American bollworm), Pectinophora gossypiella (Pink bollworm), Earias vittella (Spotted bollworm). Warm dry conditions favor outbreak.",
        "severity": "Very High — primary pest of cotton; can cause 40-60% loss without management.",
        "prevention": "Pheromone traps (2/acre for monitoring). Avoid excessive nitrogen. Use BT cotton varieties. Crop rotation. Intercropping with sorghum/maize.",
        "pesticide": "Spinosad (Tracer 45 SC) 0.3 ml/litre; Emamectin benzoate (Proclaim 5 SG) 0.5 g/litre; Chlorantraniliprole (Coragen) 0.3 ml/litre. Rotate modes of action.",
        "organic_treatment": "Bacillus thuringiensis (Bt) spray 2 g/litre (Dipel/Halt); NPV (Nuclear Polyhedrosis Virus) 250 LE/ha; Neem Seed Kernel Extract 5%; release Trichogramma egg parasitoid (50,000/acre).",
        "farming_advice": "Economic Threshold Level: 2 larvae per plant. Monitor weekly from bud initiation. Never spray same chemical class consecutively.",
    },
    "aphid": {
        "display_name": "Cotton Aphid (Sucking Pest)",
        "crop": "Cotton",
        "description": "Tiny sucking insects (Aphis gossypii) that cluster on undersides of leaves, extracting plant sap and excreting sticky honeydew that promotes sooty mold.",
        "symptoms": "Tiny green/black insects in colonies under leaves. Sticky honeydew deposits. Black sooty mold growth. Leaf curl/distortion. Yellowing. Sticky bolls.",
        "cause": "Aphis gossypii (cotton aphid). Hot dry weather with excess nitrogen promotes outbreaks. Natural enemies (ladybird beetles, syrphid flies) suppress populations.",
        "severity": "Medium — rarely causes direct yield loss but sooty mold reduces photosynthesis and contaminates fiber.",
        "prevention": "Conserve natural enemies. Avoid excessive nitrogen. Water stress makes plants more susceptible.",
        "pesticide": "Dimethoate (Rogor 30 EC) 2 ml/litre; Imidacloprid (Confidor 200 SL) 0.3 ml/litre; Thiamethoxam (Actara) 0.3 g/litre.",
        "organic_treatment": "NSKE 5% spray; strong water jet to dislodge colonies; Verticillium lecanii bioagent spray; soap water (5 ml/litre dishsoap).",
        "farming_advice": "Check Economic Threshold: 200 aphids/leaf with <10 natural enemies/plant before spraying. Natural enemies often control aphids without chemicals.",
    },
    # ── Wheat diseases ───────────────────────────────────────────────────────
    "wheat rust": {
        "display_name": "Wheat Rust (Yellow/Brown/Black Rust)",
        "crop": "Wheat",
        "description": "Fungal diseases that can devastate wheat crops. Yellow rust (stripe rust) is most dangerous in cool conditions; brown rust in warm; black rust in hot conditions.",
        "symptoms": "Yellow rust: Yellow-orange pustules in stripes along leaves. Brown rust: Orange-brown pustules randomly scattered. Black rust: Large dark brown-black pustules on stems and leaves.",
        "cause": "Puccinia striiformis (yellow), P. recondita (brown), P. graminis (black). Wind-borne spores travel hundreds of kilometers.",
        "severity": "Very High — epidemics can cause 70-100% yield loss.",
        "prevention": "Grow resistant varieties (HD-3086, DBW-187 for brown rust). Avoid late sowing. Early warning system monitoring.",
        "pesticide": "Propiconazole (Tilt 25 EC) 1 ml/litre; Tebuconazole (Folicur) 1 ml/litre; Hexaconazole 1 ml/litre. Apply at first sign.",
        "organic_treatment": "No effective organic treatment once epidemic starts. Focus on resistant varieties and timely chemical control.",
        "farming_advice": "Monitor from tillering stage. Use state agriculture department early warning system. Two sprays at 15-day interval often needed.",
    },
    # ── Soybean diseases ──────────────────────────────────────────────────────
    "soybean rust": {
        "display_name": "Soybean Rust (Asian Soybean Rust)",
        "crop": "Soybean",
        "description": "Fungal disease that appears as small tan/gray lesions with pustules on lower leaf surfaces. Spreads rapidly under warm humid conditions.",
        "symptoms": "Small (2-5mm) tan, gray, or reddish-brown lesions on lower leaf surfaces. Pustules visible on leaf undersurface. Rapid defoliation. Premature pod drop.",
        "cause": "Phakopsora pachyrhizi. Requires free moisture for infection. Spreads rapidly in warm (15-28°C) humid weather.",
        "severity": "High — can cause 10-80% yield loss.",
        "prevention": "Early sowing. Wider row spacing for air circulation. Monitor from R1 (flowering) stage.",
        "pesticide": "Tebuconazole + Trifloxystrobin (Nativo) 0.5 g/litre; Azoxystrobin (Amistar) 1 ml/litre; Propiconazole 1 ml/litre.",
        "organic_treatment": "Sulfur 80 WP 3 g/litre (preventive); Neem oil 5 ml/litre; Copper hydroxide 3 g/litre.",
        "farming_advice": "Two preventive sprays (one at pod fill) recommended in high-rust-risk years. Monitor AVRDC / ICAR soybean rust bulletins.",
    },
    # ── Tur / Pigeonpea ──────────────────────────────────────────────────────
    "tur wilt": {
        "display_name": "Tur / Pigeonpea Wilt (Fusarium Wilt)",
        "crop": "Tur (Pigeon Pea)",
        "description": "Most destructive disease of tur/pigeon pea caused by soil-borne Fusarium fungus. Causes sudden wilting and death of plants at different growth stages.",
        "symptoms": "Sudden wilting of plants. Yellowing starting from lower leaves. Dark brown discoloration in stem vascular tissue (visible when cut). Root rotting.",
        "cause": "Fusarium udum (primary). Soil-borne; persists for 6+ years. Acidic poorly-drained soils favor the disease.",
        "severity": "Very High — major constraint to tur production; can cause 100% loss in susceptible varieties.",
        "prevention": "Use wilt-resistant varieties (ICPL-87119 Asha, BRG-5). Long crop rotation (3+ years). Soil solarization. Raised bed cultivation.",
        "pesticide": "Carbendazim soil drench 1 g/litre; no effective foliar fungicide. Prevention is critical.",
        "organic_treatment": "Trichoderma harzianum seed treatment 5-10 g/kg + Rhizobium + PSB. FYM enriched with Trichoderma (1 kg/100 kg FYM). Neem cake at 250 kg/acre.",
        "farming_advice": "Uproot and burn infected plants. Never re-plant tur in affected soil for 2-3 years. Maintain good drainage.",
    },
    # ── Generic/Healthy ──────────────────────────────────────────────────────
    "healthy": {
        "display_name": "Healthy Plant",
        "crop": "All Crops",
        "description": "Your plant appears healthy with no visible signs of disease or pest damage. Continue regular monitoring and preventive care.",
        "symptoms": "No visible symptoms — plant is growing normally with healthy green color.",
        "cause": "N/A — plant is healthy.",
        "severity": "None",
        "prevention": "Continue regular field scouting (weekly). Maintain balanced fertilization and optimal irrigation.",
        "pesticide": "No chemical treatment needed at this time.",
        "organic_treatment": "Continue preventive neem oil spray (3 ml/litre) every 15 days. Apply biofertilizers as soil amendment.",
        "farming_advice": "Keep monitoring! Many diseases are easier to control when caught early. Maintain field hygiene by removing crop debris.",
    },
}

# ── HF Model label → encyclopedia key mapping ─────────────────────────────────
# Maps HuggingFace model output labels to our disease encyclopedia keys
HF_LABEL_MAP: dict[str, str] = {
    # Cotton
    "Cotton___Bacterial_blight": "bacterial blight",
    "Cotton___healthy": "healthy",
    "Cotton___Powdery_mildew": "powdery mildew",
    "Cotton___Target_spot": "alternaria leaf spot",
    # Wheat
    "Wheat___Brown_rust_(Leaf_rust)": "wheat rust",
    "Wheat___Healthy": "healthy",
    "Wheat___Loose_Smut": "wheat rust",  # Use rust info as closest
    "Wheat___Yellow_rust_(Stripe_rust)": "wheat rust",
    # Soybean
    "Soybean___healthy": "healthy",
    "Soybean___Bacterial_blight": "bacterial blight",
    "Soybean___Frogeye_leaf_spot": "alternaria leaf spot",
    "Soybean___Target_spot": "alternaria leaf spot",
    # Corn/Maize
    "Corn_(maize)___Common_rust_": "wheat rust",
    "Corn_(maize)___healthy": "healthy",
    "Corn_(maize)___Northern_Leaf_Blight": "alternaria leaf spot",
    # Tomato (common in knowledge base)
    "Tomato___healthy": "healthy",
    "Tomato___Leaf_Mold": "powdery mildew",
    "Tomato___Late_blight": "alternaria leaf spot",
    "Tomato___Early_blight": "alternaria leaf spot",
    # Potato
    "Potato___healthy": "healthy",
    "Potato___Early_blight": "alternaria leaf spot",
    "Potato___Late_blight": "alternaria leaf spot",
    # Grape
    "Grape___healthy": "healthy",
    "Grape___Black_rot": "alternaria leaf spot",
    "Grape___Leaf_blight_(Isariopsis_Leaf_Spot)": "alternaria leaf spot",
    "Grape___Esca_(Black_Measles)": "fusarium wilt",
    # Apple
    "Apple___healthy": "healthy",
    "Apple___Apple_scab": "alternaria leaf spot",
    "Apple___Black_rot": "alternaria leaf spot",
    "Apple___Cedar_apple_rust": "wheat rust",
    # Pepper
    "Pepper,_bell___healthy": "healthy",
    "Pepper,_bell___Bacterial_spot": "bacterial blight",
    # Strawberry
    "Strawberry___healthy": "healthy",
    "Strawberry___Leaf_scorch": "alternaria leaf spot",
    # Cherry
    "Cherry_(including_sour)___healthy": "healthy",
    "Cherry_(including_sour)___Powdery_mildew": "powdery mildew",
}


def _get_disease_info(label: str) -> tuple[str, dict]:
    """
    Map an HF model label to encyclopedia info.
    Returns (display_label, disease_dict).
    """
    # Try exact match first
    enc_key = HF_LABEL_MAP.get(label)

    if enc_key:
        info = DISEASE_ENCYCLOPEDIA.get(enc_key)
        if info:
            return info["display_name"], info

    # Fallback: fuzzy match against encyclopedia keys
    label_lower = label.lower().replace("_", " ").replace("(", "").replace(")", "")
    for key, info in DISEASE_ENCYCLOPEDIA.items():
        if key in label_lower or any(w in label_lower for w in key.split()):
            return info["display_name"], info

    # If label contains "healthy" anywhere
    if "healthy" in label_lower:
        info = DISEASE_ENCYCLOPEDIA["healthy"]
        return info["display_name"], info

    # Create generic info from label
    clean_label = label.replace("___", " - ").replace("_", " ").title()
    fallback_info = {
        "display_name": clean_label,
        "crop": "Unspecified",
        "description": f"Detected condition: {clean_label}. Consult your local KVK or agriculture officer for detailed advice.",
        "symptoms": "See image analysis results for visible symptoms.",
        "cause": "Analysis based on visual features. Lab confirmation recommended.",
        "severity": "Unknown — confirm with local agriculture expert.",
        "prevention": "Use certified disease-free seed. Practice crop rotation. Maintain field hygiene.",
        "pesticide": "Consult KVK helpline (1800-180-1551) for approved chemical recommendations.",
        "organic_treatment": "Neem oil 5 ml/litre spray as general preventive measure.",
        "farming_advice": "Contact your nearest Krishi Vigyan Kendra (KVK) for site-specific advice.",
    }
    return clean_label, fallback_info


def _load_hf_pipeline():
    """Lazy-load the HuggingFace disease detection pipeline."""
    global _hf_pipeline, _hf_load_attempted, _hf_available

    if _hf_load_attempted:
        return _hf_available

    _hf_load_attempted = True

    try:
        from transformers import pipeline

        logger.info(f"Loading HuggingFace model: {settings.HF_DISEASE_MODEL}")
        logger.info("First run: model will download (~350MB). Subsequent runs use cache.")

        os.makedirs(settings.HF_CACHE_DIR, exist_ok=True)

        _hf_pipeline = pipeline(
            "image-classification",
            model=settings.HF_DISEASE_MODEL,
            device=-1,  # CPU (-1), GPU (0)
            top_k=3,    # Return top 3 predictions
        )
        _hf_available = True
        logger.info("HuggingFace plant disease model loaded successfully.")
        return True

    except ImportError:
        logger.warning(
            "transformers/torch not installed. "
            "Install with: pip install transformers torch torchvision\n"
            "Falling back to local disease encyclopedia."
        )
        return False
    except Exception as e:
        import traceback
        traceback.print_exc()
        logger.error(f"Failed to load HuggingFace model: {e}")
        logger.info("Falling back to local disease encyclopedia.")
        return False


async def detect_disease(image_bytes: bytes, filename: str) -> dict:
    """
    Detect plant disease from image bytes.

    Pipeline:
      1. Validate image size and format
      2. Run HuggingFace ViT model (if available)
      3. Fallback: return informative message with local encyclopedia

    Returns:
        Comprehensive disease detection result dict.
    """
    # ── Image validation ─────────────────────────────────────────────────
    size_mb = len(image_bytes) / (1024 * 1024)
    if size_mb > settings.MAX_IMAGE_SIZE_MB:
        raise ValueError(
            f"Image too large ({size_mb:.1f} MB). "
            f"Maximum allowed: {settings.MAX_IMAGE_SIZE_MB} MB. "
            "Please compress or resize your image."
        )

    try:
        pil_img = Image.open(io.BytesIO(image_bytes)).convert("RGB")
        w, h = pil_img.size
        if w < 50 or h < 50:
            raise ValueError(
                f"Image too small ({w}×{h} pixels). "
                "Please upload a clear photo of at least 100×100 pixels."
            )
    except ValueError:
        raise
    except Exception as e:
        raise ValueError(f"Cannot read image file: {e}. Please upload a valid JPG or PNG image.")

    logger.info(f"Disease detection: file={filename}, size={size_mb:.2f}MB, dims={pil_img.size}")

    # ── HuggingFace model inference ───────────────────────────────────────
    if _load_hf_pipeline():
        try:
            predictions = _hf_pipeline(pil_img)
            # predictions = [{"label": "...", "score": 0.95}, ...]

            top = predictions[0]
            label = top["label"]
            confidence = float(top["score"])

            display_name, disease_info = _get_disease_info(label)
            is_healthy = "healthy" in label.lower() or "healthy" in disease_info.get("display_name", "").lower()

            # Confidence label
            if confidence >= 0.75:
                conf_label = "High"
            elif confidence >= 0.50:
                conf_label = "Medium"
            else:
                conf_label = "Low"

            low_conf_note = ""
            if confidence < settings.DISEASE_CONFIDENCE_THRESHOLD:
                low_conf_note = (
                    f" Note: Confidence is low ({round(confidence * 100)}%). "
                    "This may not be accurate — please consult your local KVK or agriculture officer."
                )

            # Build all predictions summary
            all_predictions = [
                {
                    "label": p["label"].replace("___", " - ").replace("_", " "),
                    "confidence": round(float(p["score"]) * 100, 1),
                }
                for p in predictions
            ]

            result = {
                "disease_name": display_name,
                "confidence_score": round(confidence, 3),
                "confidence_label": conf_label,
                "confidence_pct": round(confidence * 100, 1),
                "is_healthy": is_healthy,
                "crop": disease_info.get("crop", ""),
                "description": disease_info.get("description", "") + low_conf_note,
                "symptoms": disease_info.get("symptoms", ""),
                "cause": disease_info.get("cause", ""),
                "severity": disease_info.get("severity", ""),
                "prevention": disease_info.get("prevention", ""),
                "pesticide": disease_info.get("pesticide", ""),
                "organic_treatment": disease_info.get("organic_treatment", ""),
                "farming_advice": disease_info.get("farming_advice", ""),
                "all_predictions": all_predictions,
                "model_used": "HuggingFace ViT (Local)",
                "disclaimer": (
                    "AI-based prediction. Always confirm with local agriculture officer "
                    "or KVK helpline (1800-180-1551) before applying chemicals."
                ),
            }

            logger.info(
                f"Disease detection result: {display_name} "
                f"(confidence={round(confidence * 100, 1)}%)"
            )
            return result

        
            # Fall through to fallback
        except Exception as e:
            import traceback
            traceback.print_exc()
            logger.error(f"HuggingFace inference error: {e}")    

    # ── Fallback: informative error with guidance ─────────────────────────
    logger.warning("HF model unavailable — returning setup guidance")
    raise ValueError(
        "Local disease detection model is not loaded. "
        "Install required packages:\n"
        "  pip install transformers torch torchvision\n"
        "Then restart the backend server. "
        "The model (~350MB) will download automatically on first use.\n\n"
        "Alternative: Describe your plant symptoms to the chatbot for advice."
    )


def get_status() -> dict:
    """Return disease service status for health check."""
    hf_loaded = _load_hf_pipeline()
    return {
        "hf_model": settings.HF_DISEASE_MODEL,
        "hf_model_loaded": hf_loaded,
        "hf_cache_dir": settings.HF_CACHE_DIR,
        "confidence_threshold": settings.DISEASE_CONFIDENCE_THRESHOLD,
        "status": "ok" if hf_loaded else "degraded",
        "note": (
            "Model will load on first image upload if not yet initialized."
            if not hf_loaded
            else "Ready"
        ),
    }
