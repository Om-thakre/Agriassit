"""
config.py — Centralized Configuration for Kapus Mitra v3

All settings loaded from environment variables via .env file.
Never hardcode API keys. Import `settings` from this module everywhere.
"""

import logging
import os
from pathlib import Path

from dotenv import load_dotenv

# Load .env from the same directory as this file
load_dotenv(Path(__file__).parent / ".env")


class Settings:
    # ── Ollama (local LLM) ─────────────────────────────────────────────────
    OLLAMA_BASE_URL: str = os.getenv("OLLAMA_BASE_URL", "http://localhost:11434")
    # OLLAMA_MODEL is now auto-detected at startup — this is a fallback hint only
    OLLAMA_MODEL_HINT: str = os.getenv("OLLAMA_MODEL", "llama3.2:3b")
    OLLAMA_TIMEOUT: int = int(os.getenv("OLLAMA_TIMEOUT", "30"))

    # Preferred model priority order (first available wins)
    OLLAMA_PREFERRED_MODELS: list = [
        "llama3.2:3b",
        "qwen2.5:3b",
        "phi4-mini",
        "gemma3:4b",
        "llama3.2:1b",
        "qwen2.5:1.5b",
        "phi3:mini",
        "gemma:2b",
        "tinyllama",
    ]

    # ── HuggingFace Disease Detection ──────────────────────────────────────
    # Model runs locally after first download (~350MB). No API key needed.
    HF_DISEASE_MODEL: str = os.getenv(
        "HF_DISEASE_MODEL", "linkanjarad/plant-disease-detection-ViT-base"
    )
    HF_CACHE_DIR: str = os.getenv(
        "HF_CACHE_DIR",
        str(Path(__file__).parent / "hf_cache"),
    )
    # Confidence threshold — below this we warn the user result may be uncertain
    DISEASE_CONFIDENCE_THRESHOLD: float = float(
        os.getenv("DISEASE_CONFIDENCE_THRESHOLD", "0.50")
    )

    # ── Market data ────────────────────────────────────────────────────────
    DATA_GOV_IN_API_KEY: str = os.getenv(
        "DATA_GOV_IN_API_KEY",
        "579b464db66ec23bdd000001cdd3946e44ce4aad7209ff7b23ac571b",
    )
    DATA_GOV_IN_URL: str = (
        "https://api.data.gov.in/resource/9ef84268-d588-465a-a308-a864a43d0070"
    )
    MARKET_CACHE_TTL: int = int(os.getenv("MARKET_CACHE_TTL_SECONDS", "3600"))

    # ── General ────────────────────────────────────────────────────────────
    MAX_IMAGE_SIZE_MB: int = int(os.getenv("MAX_IMAGE_SIZE_MB", "10"))
    LOG_LEVEL: str = os.getenv("LOG_LEVEL", "INFO")


settings = Settings()


def setup_logging() -> logging.Logger:
    """Configure root logger. Call once at startup from main.py."""
    logging.basicConfig(
        level=getattr(logging, settings.LOG_LEVEL, logging.INFO),
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )
    # Silence noisy third-party loggers
    logging.getLogger("httpx").setLevel(logging.WARNING)
    logging.getLogger("httpcore").setLevel(logging.WARNING)
    logging.getLogger("transformers").setLevel(logging.WARNING)
    logging.getLogger("sentence_transformers").setLevel(logging.WARNING)
    return logging.getLogger("kapus_mitra")
