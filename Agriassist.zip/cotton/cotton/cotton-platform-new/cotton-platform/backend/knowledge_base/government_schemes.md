# Government Agricultural Schemes for Indian Farmers

## Overview

The Government of India runs several schemes to support farmers financially, provide crop insurance,
improve irrigation, and help farmers get better market prices.

## 1. PM-KISAN (PM Kisan Samman Nidhi)

- **Benefit**: ₹6,000 per year in 3 installments of ₹2,000 directly to bank account
- **Who can apply**: All landholding farmer families across India
- **How to apply**: Visit pmkisan.gov.in or nearest CSC centre
- **Documents**: Aadhaar, 7/12 land record, bank account
- **Status check**: pmkisan.gov.in → Beneficiary Status

All PM-Kisan beneficiaries are also eligible for pre-approved Kisan Credit Cards.

## 2. PM Fasal Bima Yojana (PMFBY) — Crop Insurance

- **Benefit**: Crop loss compensation for natural disasters, drought, flood, pest
- **Premium**: Only 2% for Kharif crops (like cotton, soybean), 1.5% for Rabi (wheat, gram)
- **Who**: All farmers growing notified crops; loanee farmers auto-enrolled via KCC
- **Cotton farmers**: Cotton (Kapas) is covered under PMFBY in Maharashtra — apply before July 31 for Kharif
- **Apply**: pmfby.gov.in or nearest bank/insurance office
- **Helpline**: 1800-200-7710 (toll-free)

## 3. PM-KUSUM (Solar Pump Scheme)

- **Benefit**: Install solar irrigation pumps with 60% government subsidy (farmer pays only 30%)
- **Components**:
  - Component B: Standalone solar pumps for irrigation
  - Component C: Solarize your existing electric pump
- **Apply**: pmkusum.mnre.gov.in or via state DISCOM (MSEDCL in Maharashtra)
- **Saves**: Eliminates diesel and electricity costs for irrigation

## 4. Soil Health Card Scheme

- **Benefit**: Free soil testing; card showing 12 soil parameters with fertilizer recommendations
- **Why important**: Helps reduce fertilizer overuse; can save ₹2,000–5,000 per acre
- **All farmers** can get this — no cost
- **Apply**: Visit your district agriculture office or KVK (Krishi Vigyan Kendra)
- **Check existing card**: soilhealth.dac.gov.in

## 5. Kisan Credit Card (KCC)

- **Benefit**: Crop loan up to ₹3 lakh at 4% effective interest (7% minus 3% government subvention)
- **Use for**: Seeds, fertilizers, pesticides, irrigation, farm maintenance
- **Revolving credit**: Draw and repay as needed throughout the season
- **Apply**: Any nationalized bank, cooperative bank, or RRB branch
- **No collateral** required for loans up to ₹1.6 lakh
- **Includes**: Automatic crop insurance (PMFBY) coverage

## 6. eNAM (Electronic National Agriculture Market)

- **Benefit**: Sell crops online to buyers across India; get better prices through transparent bidding
- **How it helps**: Typically 5–10% better price than traditional auctions
- **Supported crops**: Cotton, soybean, tur, wheat, gram, maize, and more
- **Mandis available**: 1000+ mandis across India; Maharashtra: Nagpur, Yavatmal, Amravati, Akola
- **Register**: enam.gov.in → Farmer Registration
- **Mobile app**: eNAM app (Google Play)

## 7. PM Krishi Sinchai Yojana (PMKSY) — Irrigation Subsidy

- **Benefit**: Drip irrigation subsidy up to 55% for small/marginal farmers; sprinkler irrigation subsidy
- **Why important**: Reduces water use by 40–50%; increases yield by 15–20%
- **Apply**: In Maharashtra — apply via MahaDBT Shetkari portal (mahadbt.maharashtra.gov.in)
- **Contact**: Taluka Agriculture Officer (TAO) in your taluka

## 8. Agriculture Infrastructure Fund (AIF)

- **Benefit**: Loans for warehouses, cold storage, primary processing with 3% interest subvention
- **Loan amount**: Up to ₹2 crore with credit guarantee
- **Who**: FPOs, SHGs, cooperatives, individual farmers and agri-entrepreneurs
- **Apply**: agriinfra.dac.gov.in or nearest NABARD/nationalized bank
- **Scheme valid**: Until 2032–33

## Quick Reference for Vidarbha Cotton Farmers

| Scheme | Key Benefit | Where to Apply |
|--------|------------|---------------|
| PM-KISAN | ₹6,000/year cash | pmkisan.gov.in |
| PMFBY | Crop loss insurance | pmfby.gov.in / Bank |
| PM-KUSUM | Solar pump (60% subsidy) | MSEDCL / MNRE |
| Soil Health Card | Free soil testing | District Agri. Office |
| KCC | Loan at 4% interest | Bank branch |
| eNAM | Better market price | enam.gov.in |
| PMKSY | Drip irrigation subsidy | MahaDBT portal |
| AIF | Warehouse/processing loan | Bank / NABARD |

## How to Get More Information

- **Kisan Call Centre**: 1800-180-1551 (Toll-free, 6 AM to 10 PM)
- **PM-KISAN Helpline**: 155261 / 011-23381092
- **PMFBY Helpline**: 1800-200-7710
- **Agriculture Ministry**: agricoop.gov.in
- **Maharashtra Agriculture Department**: mahaagri.gov.in
