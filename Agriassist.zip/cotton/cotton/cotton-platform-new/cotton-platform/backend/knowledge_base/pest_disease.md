# Pest & Disease Management — Vidarbha Cotton

## Bollworm (pink bollworm, American bollworm, spotted bollworm)
- Pink bollworm is the major concern in BT cotton regions including Vidarbha, since BT toxin
  (Cry1Ac/Cry2Ab) has reduced but not eliminated pink bollworm damage due to resistance
  development in some pockets.
- Scout weekly from squaring stage: look for rosette flowers (petals stuck together — a sign
  of pink bollworm larvae inside) and bore holes in green bolls.
- Install pheromone traps (5-8 per acre) from 45 days after sowing to monitor moth activity;
  if trap catch exceeds 8-10 moths per trap for 2-3 consecutive nights, consider a targeted
  spray.
- Avoid calendar-based spraying; spray only when scouting/traps indicate threshold is crossed,
  to slow resistance buildup.

## Whitefly
- Common in hot, dry spells and near flowering; whiteflies transmit cotton leaf curl virus in
  some regions and cause sooty mold from honeydew secretion.
- Yellow sticky traps help monitor and mildly reduce populations.
- Heavy whitefly buildup is often linked to excess nitrogen and water stress — balanced
  fertilization helps as a preventive measure.

## Bacterial blight (angular leaf spot)
- Appears as angular, water-soaked lesions on leaves, often after periods of high humidity and
  rain, common after waterlogging events in Vidarbha's mid-Kharif heavy rain spells.
- Avoid overhead irrigation where possible; remove and destroy infected plant debris; use
  disease-free/treated seed as a preventive step for the next season.

## Fungal leaf spot / boll rot
- Increases sharply after waterlogging or extended humid, cloudy weather.
- Improve field drainage (ridge-furrow), avoid dense canopy through balanced spacing/nitrogen,
  and remove severely infected bolls to slow spread.

## Nutrient deficiency vs disease (quick differentiation)
- Uniform yellowing of older/lower leaves spreading upward, with normal-shaped leaves: usually
  nitrogen deficiency.
- Yellowing between leaf veins while veins stay green (interveinal chlorosis), especially on
  younger leaves: often magnesium or iron deficiency, more common in black soils after
  prolonged waterlogging.
- Irregular spots/lesions with a defined margin, or insect damage/webbing/holes visible:
  usually disease or pest, not a deficiency.

## General advisory note
This assistant gives general, regionally-adapted guidance. Confirm exact spray schedules,
product names, and dosages with the local Krishi Vigyan Kendra (KVK) or Agriculture Department
helpline before applying any chemical.
