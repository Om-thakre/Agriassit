# Fertilizer & Nutrient Management — Vidarbha Cotton

## General dose (rainfed BT hybrid, black cotton soil)
- A commonly recommended range for rainfed Vidarbha cotton is approximately 60-90 kg
  Nitrogen, 30-45 kg Phosphorus, and 30 kg Potash per hectare, split across basal and
  top-dressing applications — exact figures vary by hybrid, soil test, and district
  recommendation, so treat this as an approximate starting range, not a fixed prescription.

## Timing/splitting
- Basal dose: full Phosphorus and Potash plus about one-third of Nitrogen, applied at/just
  after sowing.
- First top-dressing: roughly one-third of Nitrogen at squaring stage (35-45 days after
  sowing).
- Second top-dressing: remaining Nitrogen at flowering/early boll stage (60-70 days after
  sowing) — skip or delay this if the crop is under active moisture stress or waterlogging.

## Black cotton soil notes
- Regur soil is generally rich in potash and often has good native fertility but can be
  deficient in available nitrogen, zinc, and sometimes sulfur.
- A soil test every 2-3 years (available through KVK/Agriculture Department soil testing labs)
  is the most reliable way to fine-tune dosage rather than following a blanket recommendation.
- Avoid heavy nitrogen application on already vigorous, densely-canopied crops — it promotes
  vegetative growth over boll formation and increases whitefly/pest susceptibility.

## Micronutrients
- Zinc sulfate application (basal or as foliar spray) is commonly beneficial in black cotton
  soils showing pale, small, or crinkled new leaves.
- Boron deficiency can cause flower/boll shedding; a foliar boron spray during flowering is
  sometimes recommended in boron-deficient soils, but should be confirmed via soil test before
  routine use.
