# Irrigation & Moisture Management — Vidarbha Cotton

Most Vidarbha cotton is rainfed, so managing monsoon variability matters more than scheduled
irrigation for the majority of farmers. For farmers with well/borewell access, the guidance
below applies.

## Critical moisture-sensitive stages
1. Squaring/flower initiation (35-50 days after sowing)
2. Flowering to boll formation (60-90 days after sowing) — the single most moisture-sensitive
   stage; stress here causes flower and boll shedding.
3. Boll development to first picking — moderate stress is tolerable, but prolonged dryness
   reduces boll size and fiber quality.

## Dry spell (moisture stress) management
- If there is a dry spell of more than 10-12 days during flowering/boll formation and
  irrigation is available, give one life-saving irrigation.
- Where irrigation is not available, mulching with crop residue and inter-row hoeing to break
  surface crust and reduce evaporation can help conserve existing soil moisture.
- Avoid nitrogen top-dressing during an active dry spell; wait until soil moisture recovers, as
  applying nitrogen to a moisture-stressed crop can worsen stress symptoms.

## Waterlogging (excess moisture) management
- Black cotton soil drains poorly; standing water for more than 24-48 hours during flowering to
  boll stage causes root suffocation, yellowing, and sharply increases risk of fungal disease
  (root rot, boll rot) and boll shedding.
- Ridge-and-furrow or broad-bed-and-furrow (BBF) layout is the main preventive measure —
  it lets excess water drain off the field instead of pooling around the root zone.
- After a waterlogging event, as soon as the field is workable, do a shallow hoeing to break
  the surface crust and improve aeration once it dries.

## Soil moisture rule of thumb
- Below ~30-35% available soil moisture during flowering/boll stage: yield risk from moisture
  stress.
- Above ~85-90% (saturated/waterlogged) for more than a day or two during flowering/boll stage:
  yield risk from waterlogging and disease.
