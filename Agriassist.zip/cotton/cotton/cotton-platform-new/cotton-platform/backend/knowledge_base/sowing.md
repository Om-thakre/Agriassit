# Cotton Sowing — Vidarbha Region

Vidarbha districts (Akola, Amravati, Yavatmal, Nagpur, Wardha, Buldhana) grow cotton mainly as a
rainfed (Kharif) crop on black cotton (regur) soil.

## Sowing window
- Ideal sowing: first week of June to last week of June, right after the onset of the
  southwest monsoon, once there has been at least 75-100 mm of rain in a week (enough to wet
  the soil profile to sowing depth).
- Do not sow on the very first light shower — a false start followed by a dry spell can kill
  seedlings. Wait for a second confirming rain if the first rain is under 20 mm.
- Sowing after 15 July is considered "late sowing" for Vidarbha and typically reduces yield
  potential because the crop then flowers and sets bolls in cooler, shorter-day conditions.

## Spacing
- BT hybrid cotton: row-to-row spacing 90-120 cm, plant-to-plant spacing 60-90 cm depending on
  hybrid vigor and soil fertility. Denser spacing (60x30 cm) is used for high-density planting
  systems (HDPS) with compact hybrids.
- Seed rate: roughly 1.5-2.0 packets (450g each) of BT hybrid seed per acre.

## Seed treatment
- Treat seed with recommended fungicide/insecticide before sowing to reduce early sucking pest
  and seedling disease incidence, especially important in waterlogging-prone black soil.

## Black cotton soil considerations
- Regur soil has high clay content, swells when wet and cracks when dry — this affects both
  sowing depth (2.5-3.5 cm is usually enough; deeper sowing in cracking soil delays emergence)
  and drainage planning (ridge-furrow sowing helps in low-lying, waterlogging-prone fields).
