# MSP & Market Guidance — Cotton

## General principles (no invented figures)
- The Minimum Support Price (MSP) for cotton is announced by the Government of India each
  season (typically before the Kharif sowing season) and is set separately for medium-staple
  and long-staple cotton varieties.
- MSP figures change every year and this assistant does not have a live feed of current-year
  prices, so it will not state a specific rupee figure for MSP or mandi price.
- For the current season's MSP and the nearest active procurement centers (often through
  Cotton Corporation of India / CCI, or state cooperative marketing federations), the farmer
  should check:
  - The local Krishi Vigyan Kendra (KVK) or Agriculture Department office
  - The nearest Agricultural Produce Market Committee (APMC) / Krishi Utpanna Bazar Samiti
  - Government portals such as eNAM or the CCI website/helpline

## Quality factors affecting price realized
- Staple length, micronaire value, moisture content, and trash/contamination level all affect
  the price a farmer's lot fetches above or relative to MSP.
- Proper picking (avoiding contamination with leaf trash, plastic, or damp cotton) and timely
  sale (avoiding prolonged storage in humid conditions, which lowers quality) both help realize
  a better price.

## Selling channel note
- CCI procurement at MSP is typically triggered when market/mandi prices fall below MSP; when
  open-market mandi prices are above MSP, farmers usually get a better rate selling in the
  open market instead.
