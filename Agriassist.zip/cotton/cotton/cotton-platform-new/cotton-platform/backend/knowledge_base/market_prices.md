# Mandi (Agricultural Market) Prices — Vidarbha & India Reference

## About Mandi Prices

Agricultural commodity prices are quoted in **₹ per quintal (100 kg)** at APMC mandis.
Prices shown are: Minimum Price, Maximum Price, and Modal Price (most common transaction price).

## Key Price Reference — Kharif Season 2026

### Cotton (Kapas / Raw Cotton)
- Cotton is the primary cash crop in Vidarbha districts (Yavatmal, Akola, Amravati, Nagpur, Wardha, Washim).
- MSP (Minimum Support Price) for Cotton (Medium Staple) 2025-26: ₹7,121 per quintal
- MSP for Cotton (Long Staple) 2025-26: ₹7,521 per quintal
- Current Mandi Prices (July 2026):
  - Yavatmal: ₹6,200 – ₹7,100 (Modal: ₹6,680)
  - Akola: ₹6,300 – ₹7,200 (Modal: ₹6,750)
  - Amravati: ₹6,100 – ₹6,950 (Modal: ₹6,550)
  - Nagpur: ₹6,250 – ₹7,050 (Modal: ₹6,650)
- Cotton prices are influenced by global demand, CCI (Cotton Corporation of India) procurement, and textile sector demand.

### Tur / Arhar (Red Gram / Pigeon Pea)
- Important pulse crop in Marathwada and Vidarbha
- MSP for Tur 2025-26: ₹7,000 per quintal
- Current Mandi Prices (July 2026):
  - Latur: ₹6,500 – ₹7,400 (Modal: ₹6,950)
  - Akola: ₹6,400 – ₹7,300 (Modal: ₹6,850)

### Soybean
- Major oilseed crop in Madhya Pradesh and Maharashtra
- MSP for Soybean (Yellow) 2025-26: ₹4,892 per quintal
- Current Mandi Prices (July 2026):
  - Indore (MP): ₹3,800 – ₹4,600 (Modal: ₹4,200)
  - Latur: ₹3,750 – ₹4,550 (Modal: ₹4,150)
  - Yavatmal: ₹3,700 – ₹4,500 (Modal: ₹4,100)

### Wheat
- Rabi crop; key in Punjab, Haryana, MP, UP
- MSP for Wheat 2025-26: ₹2,275 per quintal
- Current Mandi Prices (July 2026):
  - Amritsar: ₹2,100 – ₹2,400 (Modal: ₹2,250)
  - Indore: ₹2,050 – ₹2,350 (Modal: ₹2,200)

### Gram / Chana (Bengal Gram / Chickpea)
- Rabi pulse crop
- MSP for Gram (Chana) 2025-26: ₹5,440 per quintal
- Current Mandi Prices (July 2026):
  - Akola: ₹4,600 – ₹5,400 (Modal: ₹5,000)
  - Jaipur: ₹4,700 – ₹5,500 (Modal: ₹5,100)

### Maize
- Kharif and Rabi crop
- MSP for Maize 2025-26: ₹2,090 per quintal
- Current Mandi Prices (July 2026):
  - Davangere (Karnataka): ₹1,750 – ₹2,100 (Modal: ₹1,950)
  - Pune: ₹1,720 – ₹2,050 (Modal: ₹1,900)

## MSP (Minimum Support Price) Information

MSP is the minimum price guaranteed by the Government of India for specific crops.
If mandi prices fall below MSP, government agencies (FCI, CCI, NAFED, state agencies) procure at MSP.

Key MSPs for 2025-26 Kharif:
- Cotton (Medium Staple): ₹7,121/quintal
- Cotton (Long Staple): ₹7,521/quintal
- Soybean (Yellow): ₹4,892/quintal
- Tur (Arhar): ₹7,000/quintal
- Maize: ₹2,090/quintal
- Groundnut (in shell): ₹6,783/quintal

## Where to Check Live Prices

1. AGMARKNET portal: agmarknet.gov.in
2. eNAM portal: enam.gov.in
3. State government agriculture department websites
4. Maharashtra: mahaemart.com (state mandi portal)
5. Kapus Mitra app: Market Prices tab (updated daily)

## Tips for Farmers

- Always compare prices at multiple mandis before selling
- Check if your crop qualifies for MSP procurement in your district
- Sell via eNAM for better price discovery through online bidding
- Cotton: avoid distress selling — wait for CCI procurement if prices are below MSP
- Store grains (wheat, gram, maize) in warehouses for 2–3 months after harvest for better prices
